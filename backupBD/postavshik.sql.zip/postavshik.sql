-- phpMyAdmin SQL Dump
-- version 4.9.7
-- https://www.phpmyadmin.net/
--
-- Хост: localhost
-- Время создания: Мар 16 2024 г., 00:21
-- Версия сервера: 5.7.21-20-beget-5.7.21-20-1-log
-- Версия PHP: 5.6.40

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `ruslarjn_lktilda`
--

-- --------------------------------------------------------

--
-- Структура таблицы `postavshik`
--
-- Создание: Мар 15 2024 г., 21:19
--

DROP TABLE IF EXISTS `postavshik`;
CREATE TABLE `postavshik` (
  `id` int(11) NOT NULL,
  `id_old` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `api_key` varchar(300) NOT NULL,
  `updated` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `balans` varchar(50) NOT NULL,
  `currency` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `postavshik`
--

INSERT INTO `postavshik` (`id`, `id_old`, `name`, `api_key`, `updated`, `balans`, `currency`) VALUES
(1, 2, 'https://xerdctgyhu.socpanel.com/api/v2', 'Fda0umtq4G0rIqV20BmJtRS6niQwXDhnQzINmPk94JByfRk83ckoiBeSD0xk', '2024-03-15 19:13:13', '', ''),
(2, 3, 'https://prosmmpanel.ru/api/v2', 'sG0OT9AuMlGjzgDJ8lp232fdyXUfNaoJS8IPw7xwPwiUbnXFvk0OH3nadgHC', '2024-03-15 19:13:13', '', ''),
(3, 5, 'https://goodpanel.biz/api/v2', 'af6f519b201cc2cc0b184b6ef02399d4', '2024-03-15 19:13:13', '', ''),
(4, 6, 'https://smmmain.com/api/v2', 'c1cbadc0255c939d681be07700c1a7eb', '2024-03-15 19:13:13', '', ''),
(5, 7, 'https://smm-liderpanel.com/api/v2', '956c83cfdb01927e71c8ea81fe250900', '2024-03-15 19:13:13', '', ''),
(6, 8, 'https://turkiyeresellers.net/api/v2', '08e5e0f69a417ffa65019c1c28e21b78', '2024-03-15 19:13:13', '', ''),
(7, 9, 'https://justanotherpanel.com/api/v2', '469adee1600962cc140f88e2b0f010fc', '2024-03-15 19:13:13', '', ''),
(8, 10, 'https://bestexpertz.com/api/v2', '1f6cb26d06741387416934df813ad59d30c0e465', '2024-03-15 19:13:13', '', ''),
(9, 11, 'https://fastpanel.io/api/v2', '375b49355b1d69a5ecbb0beb2f199700', '2024-03-15 19:13:13', '', ''),
(10, 12, 'https://smmrapid.com/api/v2', '31bc49d14e578041b5a69df9e8a6cb49', '2024-03-15 19:13:13', '', ''),
(11, 13, 'https://ytlikes.com/api/v2', 'd5a74b41263997829bdb3c42d3b74526', '2024-03-15 19:13:13', '', ''),
(12, 14, 'https://peakerr.com/api/v2', '4f5c64da004b0ef9a3563a5cd3fc140e', '2024-03-15 19:13:13', '', ''),
(13, 15, 'https://beingpanel.com/api/v2', '3f2c65a68d9069c89e6b6c42fae7da73', '2024-03-15 19:13:13', '', ''),
(14, 16, 'https://likesmm.net/api/v2', 'd435f4980628d6adcde6e57d8dacfc93', '2024-03-15 19:13:13', '', ''),
(15, 17, 'https://telesubs.com/api/v2', '1005dd1f6df2d8a4d9a3587d756ddaa5', '2024-03-15 19:13:13', '', ''),
(16, 18, 'https://global-smm.com/api/v2', 'b698f96ea64fb6414386d1bd56df13a6', '2024-03-15 19:13:13', '', ''),
(17, 19, 'https://smmxboost.com/api/v2', '30a0b0dc8a51327a0219177371f7eb25', '2024-03-15 19:13:13', '', ''),
(18, 20, 'https://smmjobz.com/api/v2', 'dd5a13d0c127cdf730447bcbd52fd943', '2024-03-15 19:13:13', '', ''),
(19, 21, 'https://www.smmraja.com/api/v3', 'Y7r)iHz*0)Xzc(L)Q*Q2*3', '2024-03-15 19:13:13', '', ''),
(20, 23, 'https://5252.su/api/v2', '6e322596c93a99e72c3e00a64240590c', '2024-03-15 19:13:13', '', ''),
(21, 24, 'https://like-clik.ru/api/v2', '40b4f7f9eea09900c3f9afc0d6659774', '2024-03-15 19:13:13', '', ''),
(22, 25, 'https://n1panel.com/api/v2', 'db5f4e37c80da6013487e081fedd8983', '2024-03-15 19:13:13', '', ''),
(23, 26, 'https://viralsmm.com/api/v2', 'ff02da83486a5d432ebb0938b8497c8b', '2024-03-15 19:13:13', '', ''),
(24, 27, 'https://dezesmm.com/api/v2', 'bSEnuJuODhcukSxGFTtNb9c8iu4b1UV20MJrhUVUFXJ2X88SqxZA5xJN865n', '2024-03-15 19:13:13', '', ''),
(25, 28, 'https://telegabotz.ru/api/v2', '3zCrUp6kwd7Aurfrxbaee8a4Nozsk8CeOLOI9ozCwDFb4wRVyt1bSGYMzdib', '2024-03-15 19:13:13', '', ''),
(26, 29, 'https://teateagram.com/api/v2', 'vwq4u94jrTFn4a32O2bIqQKtR9PDKLM0xfGYXJ8OJAD3OdXzwvfHd68QXjpf', '2024-03-15 19:13:13', '', ''),
(27, 30, 'https://smmkings.com/api/v2', '95f91e6574ed54afbf7f740a84f57dac', '2024-03-15 19:13:13', '', ''),
(28, 31, 'https://sochype.com/api/v2', 'i07A9qOet4xfeHCxEVW4saP2nBlHtjD4qXmzhtxjqJKzSiBo8Lt2AwfCzBhV', '2024-03-15 19:13:13', '', ''),
(29, 32, 'https://karandash.shop/api/v2', 'gtVEKLET50NlC0fvKdiKeStxUsRoFMKugWSIc1oZ05fVu2JKb2Z1DREzc6wY', '2024-03-15 19:13:13', '', ''),
(30, 33, 'https://alipanel.com/api/v2', 'BmiXyHGm5NzXYQDw8X0i9SQRXVqOnGxSUAtCVhjmSCojXYhklnPS6dRuJwPv', '2024-03-15 19:13:13', '', ''),
(31, 34, 'https://socweb.net/api/v2', 'aopqK2okExza4dR775yADsEHyabvMbITHA592fx5u7Gy4yhZfYFdN7hRKPlO', '2024-03-15 19:13:13', '', ''),
(32, 35, 'https://wiq.ru/api/', '1cc234309007e993b27ad50e250a30d5', '2024-03-15 22:42:11', '', '');

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `postavshik`
--
ALTER TABLE `postavshik`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `postavshik`
--
ALTER TABLE `postavshik`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
